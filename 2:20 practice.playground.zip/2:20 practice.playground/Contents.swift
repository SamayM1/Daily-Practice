// 2/20 Practice

// Methods


class PrintName {
    func printOutput(_ name:String)-> String{
        return name
        
    }
}

let a = PrintName()
a.printOutput("Samay")


class Counter {
    var count = 0
    func increment(){
        count += 1
    }
        
    
    func incrementBy(_ amt:Int) { // adding "_" allows user to not have to define paramaters in call
        count += amt
    }
    
    func reset(){
        count = 0
        
    }
    
    func printCount(){
        print(count)
    }
}

let b = Counter()
b.increment()
b.reset()
b.increment()
b.incrementBy(10)
b.printCount()

