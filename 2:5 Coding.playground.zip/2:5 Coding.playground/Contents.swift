struct DatabaseManager{
    //function to save data and return true if successful
    func saveData(data: String) -> Bool{
        //code to save data would go in here
        return true
    }
}



struct MyStructure{
    //property
    var msg = "Hi"
    
    //method
    func myFunction(){
        //print(msg)
        var db:DatabaseManager = DatabaseManager()
        let succ = db.saveData(data: "Hello")
    }
}

//instance: piece of data that we want to keep track of
var a:MyStructure = MyStructure()
//the datatype of a structure is the name of the structure itself. You instantiate it by writing the name of the structure followed by ()

a.msg = "Hello"
a.myFunction()

//you can create mutiple instances of a structure
var b = MyStructure()
b.myFunction()
