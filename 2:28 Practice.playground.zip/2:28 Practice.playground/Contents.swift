// 2/28 Practice

class Animal {
    var name: String
    init(name: String) {
        self.name = name
    }
    func makeSound() {
        print("Animal Sound")
    }
}


class Dog: Animal {
    override init(name: String) {
        super.init(name: name)
    }
    override func makeSound() {
        print("Ruff ruff")
    }
    func fetch() {
        print("\(name) is fetching the ball")
    }
}


class Cat: Animal {
    override init(name: String) {
        super.init(name: name)
    }
    override func makeSound() {
        print("Meow!")
    }
    func chaseMouse() {
        print("\(name) is chasing a mouse")
    }
}

let myDog = Dog(name: "Samay")
let myCat = Cat(name: "Adhi")
print("Dog's name: \(myDog.name)")
myDog.makeSound()
myDog.fetch()
print("\nCat's name: \(myCat.name)")
myCat.makeSound()
myCat.chaseMouse()

 
