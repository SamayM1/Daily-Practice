// 2/10 practice


func mean(_ numbers: Double...) -> Double {
    var total: Double = 0
    for number in numbers {
        total += number
    }
    return total / Double(numbers.count)
}

print(mean(10,20))


func add(_ a: Int, _ b: Int) -> Int {
    return (a + b)
}
func multiply(_ a: Int, _ b: Int) -> Int {
    return (a * b)
}

print(add(5,10))
print(multiply(5,10))

var math: (Int, Int) -> Int = add

print(math(1,2))


func chooseStepFunction(backward: Bool) -> (Int) -> Int {
    func stepForward(input: Int) -> Int { return input + 1 }
    func stepBackward(input: Int) -> Int { return input - 1 }
    return backward ? stepBackward : stepForward
}
var currentValue = -4
let moveNearerToZero = chooseStepFunction(backward: currentValue > 0)

while currentValue != 0 {
    print("\(currentValue)... ")
    currentValue = moveNearerToZero(currentValue)
}
print("zero!")
 
