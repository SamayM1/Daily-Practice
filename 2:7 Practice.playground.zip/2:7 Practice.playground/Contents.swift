// 2-7 Practice


let point = (2, 2)
switch point {
case (0, 0):
    print("\(point) is at the origin")
case (_, 0):
    print("\(point) is on the x-axis")
case (0, _):
    print("\(point) is on the y-axis")
case (-2...2, -2...2):
    print("\(point) is inside the box")
default:
    print("\(point) is outside of the box")
}



let someCharacter: Character = "z"
switch someCharacter {
case "a", "e", "i", "o", "u":
    print("\(someCharacter) is a vowel")
case "b", "c", "d", "f", "g", "h", "j", "k", "l", "m",
    "n", "p", "q", "r", "s", "t", "v", "w", "x", "y", "z":
    print("\(someCharacter) is a consonant")
default:
    print("\(someCharacter) isn't a vowel or a consonant")
}
 


let input = "Planters peanuts are the best"
var output = ""
let charstoremove:[Character] = ["a","e","i","o","u"]

for char in input {
    if charstoremove.contains(char) {
        continue
    }
    output.append(char)
}
print(output)


func greet(person: [String: String]) {
    guard let name = person["name"] else {
        return
    }


    print("Hello \(name)!")


    guard let location = person["location"] else {
        print("I hope the weather is nice near you.")
        return
    }


    print("I hope the weather is nice in \(location).")
}

greet(person: ["name":"Samay","location":"Texas"])
