//DT Types
/*
import Foundation
var myVar:String = "Hello"
myVar = "Bye"
print(myVar)


var myInt:Int = 20
myInt+=1
print(myInt)

let myConst:String = "Hi"

var a:Double = 2.3
var b:Double = 5.8
var c = floor(a)
var d = ceil(b)
print(c)
print(d)



let taxRate = 1.0833
let subTotal = 15.0
var Total = subTotal * taxRate
let individualAmt = Total/3


//Function
//Function Declaration
func myFunc(_ a:Int,_ b:Int = 0) -> Int{
    return (a+b)

}




//Argument Labels
// Putting _ before func parameters, makes it easier to call
func myFunc(first a:Int, second b:Int = 0) -> Int{
    return (a-b)

}


print(myFunc(10))
print(myFunc(first:10, second: 5))


func costSplit(_ tax_rate:Double,_ subtotal:Double,_ numberofpeople:Double)-> Double{
    let total = ((1+(tax_rate/100)) * subtotal)/numberofpeople
    return total
    
}

print(costSplit(8.33,15.0,3))

*/
struct ChatView{
    // Variable and Conditions:(Aka PROPERTIES)
    var msg: String = "hi there" // Global, stored property
    
    var msgWithPrefix:String{
        return "Jack says "+msg
    }
    
    //UI code: View Code
    
    
    
    // Functions
    func sendChat(){
        //code to send chat
        print(msg)
        print(msgWithPrefix)
    }
    
    func deleteChat(){
        print(msg)
    }
}

var a = ChatView()
a.sendChat()
