
var myList: [Int] = [1,2,3,4,5]
myList.removeLast()
for item in myList{
    print("item")
}


var studentID : Set = [112, 114, 116, 118, 115]
studentID.insert(119)
print(studentID)



var favoriteGenres: Set<String> = []
if favoriteGenres.isEmpty {
    favoriteGenres.insert("Hola")
    print("As far as music goes, I'm not picky.")
    print(favoriteGenres)
} else {
    print("I have particular music preferences.")
}

var mySet: Set<Int> = [1,2,3,4,5]
for nums in mySet {
    print(nums)
}


let a:Set = [1,2,3]
let b:Set = [0,1,2,3,4]
let c:Set = [1,2,3,7,9,10]
print(a.isSubset(of: c))


var adict:[Int:String] = [1:"A"]
print(adict)
