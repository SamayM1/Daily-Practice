// 2/8 Practice


var score = 15
if score == 15 {
    defer {
        print("Finally")
    }
    print("First")
}


@available(macOS 10.12, *)
struct ColorPreference {
    var bestColor = "blue"
}


func chooseBestColor() -> String {
    guard #available(macOS 10.12, *) else {
       return "gray"
    }
    let colors = ColorPreference()
    return colors.bestColor
}


func greet(name: String) -> String {
    return("Howdy \(name)!")
}

func greetAgain(name:String) -> String{
    return("Howdy again \(name)!")
}

 

func greet(name: String, alreadyGreeted: Bool) -> String {
    if alreadyGreeted {
        return greetAgain(name: name)
    } else {
        return greet(name: name)
    }
}
print(greet(name: "Samay", alreadyGreeted: false))

 

func greet(person: String, ht hometown: String) -> String {
    return "Howdy \(person)!  Glad you could visit from \(hometown)."
}
print(greet(person: "Samay", ht: "Dallas"))
