// 2/6 - Daily Coding Practice


let names = ["Samay", "Adhi", "Ash", "Om"]
for name in names {
    print("Hola ")
}


let statesFullForm:[String:String] = ["TX": "Texas", "MT": "Montana", "FL": "Florida"]
for (shortform, longform) in statesFullForm {
    print("\(shortform) stands for \(longform)")
}


 
 let freezeWarning: String? = if temperatureInCelsius <= 0 {
     "It's below freezing. Watch for ice!"
 } else {
     nil
 }
 
 
let weatherAdvice = if temperatureInCelsius > 100 {
    throw TemperatureError.boiling
} else {
    "It's a reasonable temperature."
}

 
let x = 7
switch x {
    
case 5:
    print("Hello")
case 6:
    print("Hi")
default:
    print("Everything else")
}


let approximateCount = 62
let countedThings = "moons orbiting Saturn"
let naturalCount: String
switch approximateCount {
case 0:
    naturalCount = "no"
case 1..<5:
    naturalCount = "a few"
case 5..<12:
    naturalCount = "several"
case 12..<100:
    naturalCount = "dozens of"
case 100..<1000:
    naturalCount = "hundreds of"
default:
    naturalCount = "many"
}
print("There are \(naturalCount) \(countedThings).")

