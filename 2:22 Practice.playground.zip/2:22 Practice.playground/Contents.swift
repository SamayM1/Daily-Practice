// 2/22 Practice


// A subscript enables you to query instances of a type by writing one or more values in square brackets after the instance name

struct TimesTable {
    let multiplier: Int
    subscript(index: Int) -> Int {
        return multiplier * index
    }
}
let threeTimesTable = TimesTable(multiplier: 5)
print("five times 10 is \(threeTimesTable[10])")
 
 
 
var animals = ["cat","dog","rabbit","lion"]
print(animals[1])




struct animal{
    subscript(index:Int) -> Int {
        get{
            animals[index]
        }
        set{
            animals[index+1]
        }
    }
    
}
