// 2/15 Practice

enum compass {
    case up
    case down
    case right
    case left
}

var direction = compass.left

direction = .up
switch direction {
case .up:
    print("Go north")
case .down:
    print("Go south")
case .right:
    print("Go east")
case .left:
    print("Go west")
}

enum Planet: Int {
    case mercury = 1, venus, earth, mars, jupiter, saturn, uranus, neptune,  nine, ten , eleven
}

let positionToFind = 11
if let somePlanet = Planet(rawValue: positionToFind) {
    switch somePlanet {
    case .earth:
        print("Mostly harmless")
    default:
        print("Not a safe place for humans")
    }
} else {
    print("There isn't a planet at position \(positionToFind)")
}



struct printHi {
    class print {
        print("Hi")
    }
    
}
a = print
a.print
